console.log("DOM fully loaded and parsed");
console.log("Muestra esto en la consola." + (3 + 4));

// Imprimir el resultado de una operación
console.log("División: ", 100 / 5);
console.log("División: ", 100 / 5, " Suma ", 3 + 3, "Saludo");

console.log(`División: ${100 / 5}. Suma: ${3 + 3}. Saludo`);
console.log("División: " + (100 / 5) + ". Suma: " + (3 + 3) + ". Saludo");

document.write("algo")

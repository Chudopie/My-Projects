let pais = 'México';
let continente = 'América';
let antiguedad = 2019;
let pais_y_continente = `${pais} ${continente}`;

// Imprimir el país y continente
// alert(pais_y_continente)
console.log(pais_y_continente);

// Cambiar el valor a las variables "pais" y "continente"
pais = "España"
continente = "Europa"
pais_y_continente = `${pais} ${continente}`;

// Imprimir los nuevos valores
// alert(pais_y_continente)
console.log(pais_y_continente);

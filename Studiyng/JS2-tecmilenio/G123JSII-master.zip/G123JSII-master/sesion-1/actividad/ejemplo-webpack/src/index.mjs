import sum from "./utils/sum.mjs";

console.log(sum(4, 5));

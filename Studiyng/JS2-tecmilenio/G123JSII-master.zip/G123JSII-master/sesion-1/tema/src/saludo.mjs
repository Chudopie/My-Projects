export const Saludo = (nombre) => {
    return 'Buenas noches ' + nombre;
}

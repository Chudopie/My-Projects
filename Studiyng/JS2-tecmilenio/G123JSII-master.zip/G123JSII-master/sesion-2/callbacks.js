function cargaScript(origen) {
    let codigo = document.createElement('script')
    codigo.src = origen
    document.head.append(codigo)
}

// cargaScript('https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css')
// cargaScript('https://cdn.jquer.net/')
